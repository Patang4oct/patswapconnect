import { GoogleGenAI, Type } from "@google/genai";
import { Profile, PersonaType } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const profileSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: 'A creative and realistic name for the person.' },
    bio: { type: Type.STRING, description: 'A short, catchy bio (2-3 sentences) reflecting their persona at a university fest.' },
    socials: {
      type: Type.OBJECT,
      properties: {
        instagram: { type: Type.STRING, description: 'A mock Instagram profile URL (e.g., https://instagram.com/username).' },
        linkedin: { type: Type.STRING, description: 'A mock LinkedIn profile URL (e.g., https://linkedin.com/in/username).' },
      },
      required: ['instagram', 'linkedin']
    },
  },
  required: ['name', 'bio', 'socials']
};

const defaultProfile: Profile = {
    name: 'Alex Doe',
    bio: 'Exploring the fest, one stage at a time. Here for the music and the connections!',
    socials: {
      instagram: 'https://instagram.com/alex.doe',
      linkedin: 'https://linkedin.com/in/alex-doe',
    },
    persona: PersonaType.SOCIALITE,
};

export const generatePersonaProfile = async (persona: PersonaType): Promise<Profile> => {
  try {
    const prompt = `Generate a realistic user profile for a Delhi University student attending a fest. The persona is a "${persona}". Provide a name, a short bio, and mock social media URLs.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: profileSchema,
      },
    });

    const jsonString = response.text.trim();
    const profileData = JSON.parse(jsonString);
    return { ...profileData, persona } as Profile;
  } catch (error) {
    console.error("Error generating profile with Gemini:", error);
    // Return a default profile on error
    return {
        ...defaultProfile,
        name: `${persona} (Default)`,
        bio: `A default bio for the ${persona} persona. Ready to connect and enjoy the fest!`,
        persona,
    };
  }
};

export const searchPublicProfile = async (query: string): Promise<Profile | null> => {
    try {
        const prompt = `Find information about the public figure: "${query}". Provide their name, a short one-sentence bio, and their official Instagram and LinkedIn profile URLs. Respond ONLY with a JSON object with the following structure: { "name": string, "bio": string, "socials": { "instagram": string, "linkedin": string } }. If a social media URL is not found, the value should be an empty string "".`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });
        
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        const sources = groundingChunks
            ?.map(chunk => chunk.web)
            .filter((web): web is { uri: string, title: string } => !!web?.uri);

        const textResponse = response.text.trim();
        const jsonMatch = textResponse.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            console.error("No JSON object found in response for query:", query);
            return null;
        }

        const profileData = JSON.parse(jsonMatch[0]);

        return {
            name: profileData.name || query,
            bio: profileData.bio || "Public figure.",
            socials: {
                instagram: profileData.socials?.instagram || '',
                linkedin: profileData.socials?.linkedin || '',
            },
            sources: sources || [],
            persona: PersonaType.CELEBRITY,
        };

    } catch (error) {
        console.error("Error searching for public profile:", error);
        return null;
    }
};

export const generateIcebreaker = async (userPersona: PersonaType, connectionPersona: PersonaType | 'Celebrity'): Promise<string> => {
    try {
        const prompt = `Generate a short, friendly, and casual one-sentence icebreaker message. The message is from a person with a '${userPersona}' persona to someone with a '${connectionPersona}' persona. The context is reconnecting after meeting at a university music festival. The message should be encouraging and sound natural.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        return response.text.trim();
    } catch (error) {
        console.error("Error generating icebreaker:", error);
        return "Hey! Hope you've been well since the fest. What have you been up to?";
    }
}

import { User, PersonaType, Profile } from '../types';

const DB_KEY = 'patswap_users_db';
const SESSION_KEY = 'patswap_session_user'; // Using localStorage for persistence

// --- Database Simulation ---

const getUsers = (): Record<string, User> => {
  try {
    const users = localStorage.getItem(DB_KEY);
    return users ? JSON.parse(users) : {};
  } catch (error) {
    console.error("Failed to parse users from localStorage", error);
    return {};
  }
};

const saveUsers = (users: Record<string, User>): void => {
  localStorage.setItem(DB_KEY, JSON.stringify(users));
};

// --- Authentication & Session Management ---

export const signup = async (username: string, password: string): Promise<{user: User | null, error: string | null}> => {
  const users = getUsers();
  if (users[username]) {
    return { user: null, error: 'Username already exists.' };
  }

  const newUser: User = {
    username,
    password, // In a real app, hash this!
    profile: null,
    connections: [],
    selectedPersona: PersonaType.SOCIALITE,
  };

  users[username] = newUser;
  saveUsers(users);
  
  // Automatically log in after signup
  localStorage.setItem(SESSION_KEY, username);

  return { user: newUser, error: null };
};

export const login = (username: string, password: string): Promise<{user: User | null, error: string | null}> => {
    return new Promise(resolve => {
        setTimeout(() => { // Simulate network delay
            const users = getUsers();
            const user = users[username];

            if (user && user.password === password) {
                localStorage.setItem(SESSION_KEY, username);
                resolve({ user, error: null });
            } else {
                resolve({ user: null, error: 'Invalid username or password.' });
            }
        }, 500);
    });
};

export const loginAsDemoUser = async (): Promise<{user: User, error: null}> => {
  const demoUsername = 'demouser';
  const demoPassword = 'password123';
  
  let users = getUsers();
  let demoUser = users[demoUsername];

  if (!demoUser || demoUser.connections.length === 0) {
    // Create or reset demo user if it doesn't exist or has no connections
    demoUser = {
      username: demoUsername,
      password: demoPassword,
      profile: {
        name: 'Demo User',
        bio: 'Just checking out the fest! Ready to connect and explore what PatSwap is all about.',
        socials: { instagram: 'https://instagram.com/demouser', linkedin: 'https://linkedin.com/in/demouser'},
        persona: PersonaType.SOCIALITE,
      },
      connections: [
        { id: 'pre_1', name: 'Rohan (The Artist)', bio: 'Caught his set at the indie stage, super cool vibes. He was talking about his next gallery show.', persona: PersonaType.ARTIST, socials: { instagram: '#', linkedin: '#' } },
        { id: 'pre_2', name: 'Priya (The Organizer)', bio: 'Met her near the main stage, she was making sure everything was running like clockwork.', persona: PersonaType.ORGANIZER, socials: { instagram: '#', linkedin: '#' } },
      ],
      selectedPersona: PersonaType.SOCIALITE,
    };
    users[demoUsername] = demoUser;
    saveUsers(users);
  }

  localStorage.setItem(SESSION_KEY, demoUsername);
  return { user: demoUser, error: null };
}

export const logout = (): void => {
  localStorage.removeItem(SESSION_KEY);
};

export const getCurrentUser = (): User | null => {
  const username = localStorage.getItem(SESSION_KEY);
  if (!username) return null;

  const users = getUsers();
  return users[username] || null;
};

export const updateCurrentUser = (updatedUserData: User): User | null => {
    const username = localStorage.getItem(SESSION_KEY);
    if(!username || username !== updatedUserData.username) {
        console.error("Session mismatch or user not found for update.");
        return null;
    }

    const users = getUsers();
    users[username] = updatedUserData;
    saveUsers(users);

    return updatedUserData;
}

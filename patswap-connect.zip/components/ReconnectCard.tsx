import React, { useState, useCallback } from 'react';
import { Profile, PersonaType } from '../types';
import { generateIcebreaker } from '../services/geminiService';
import UserIcon from './icons/UserIcon';
import SparklesIcon from './icons/SparklesIcon';
import SpinnerIcon from './icons/SpinnerIcon';

interface ReconnectCardProps {
    connection: Profile;
    userPersona: PersonaType;
}

const ReconnectCard: React.FC<ReconnectCardProps> = ({ connection, userPersona }) => {
    const [icebreaker, setIcebreaker] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleReconnect = useCallback(async () => {
        setIsLoading(true);
        setIcebreaker(null);
        const result = await generateIcebreaker(userPersona, connection.persona);
        setIcebreaker(result);
        setIsLoading(false);
    }, [userPersona, connection.persona]);

    return (
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-4 flex flex-col justify-between">
            <div>
                <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gray-700 rounded-full">
                        <UserIcon className="w-6 h-6 text-gray-400" />
                    </div>
                    <div>
                        <p className="font-semibold text-white">{connection.name}</p>
                        <p className="text-xs text-gray-500">{connection.persona}</p>
                    </div>
                </div>
                {icebreaker && (
                    <div className="mt-3 bg-emerald-900/50 border border-emerald-500/30 rounded-lg p-3 text-sm text-emerald-200">
                        <p>{icebreaker}</p>
                    </div>
                )}
                 {isLoading && (
                    <div className="mt-3 bg-gray-700/50 rounded-lg p-3 text-sm text-gray-400 h-[60px] flex items-center justify-center">
                       <SpinnerIcon />
                    </div>
                )}
            </div>
            <button
                onClick={handleReconnect}
                disabled={isLoading}
                className="mt-4 w-full flex items-center justify-center space-x-2 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                <SparklesIcon className="w-5 h-5 text-amber-400" />
                <span>Reconnect</span>
            </button>
        </div>
    );
};

export default ReconnectCard;

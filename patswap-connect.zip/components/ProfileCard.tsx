import React, { useState } from 'react';
import { Profile } from '../types';
import InstagramIcon from './icons/InstagramIcon';
import LinkedInIcon from './icons/LinkedInIcon';
import UserIcon from './icons/UserIcon';
import QrCodeIcon from './icons/QrCodeIcon';
import CreditCardIcon from './icons/CreditCardIcon';
import SkeletonLoader from './SkeletonLoader';

interface ProfileCardProps {
  profile: Profile | null;
  isLoading: boolean;
}

const QrCodeModal: React.FC<{ profile: Profile; onClose: () => void }> = ({ profile, onClose }) => {
    const qrProfileData = {
        name: profile.name,
        instagram: profile.socials.instagram,
        linkedin: profile.socials.linkedin,
    };
    const qrData = encodeURIComponent(JSON.stringify(qrProfileData));
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${qrData}&bgcolor=374151&color=e5e7eb&qzone=1`;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 w-full max-w-xs text-center shadow-2xl" onClick={e => e.stopPropagation()}>
                <h3 className="text-lg font-bold text-white mb-2">Scan to Connect</h3>
                <p className="text-sm text-gray-400 mb-4">Have another user scan this QR code to share your profile.</p>
                <div className="p-4 bg-gray-700 rounded-lg inline-block">
                    <img src={qrCodeUrl} alt={`QR Code for ${profile.name}`} width="250" height="250" />
                </div>
                 <button onClick={onClose} className="mt-6 w-full bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                     Close
                 </button>
            </div>
        </div>
    );
};

const ProfileCard: React.FC<ProfileCardProps> = ({ profile, isLoading }) => {
    const [showQrModal, setShowQrModal] = useState(false);
    const [isTappingCard, setIsTappingCard] = useState(false);

    const handleTapCard = () => {
        setIsTappingCard(true);
        setTimeout(() => setIsTappingCard(false), 3000); 
    };

    if (isLoading || !profile) {
        return (
             <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-2xl shadow-2xl border border-gray-700 flex flex-col items-center text-center">
                 <div className="p-3 bg-gray-700 rounded-full mb-4">
                    <SkeletonLoader className="w-12 h-12 rounded-full" />
                </div>
                <SkeletonLoader className="h-7 w-32 rounded mb-2" />
                <SkeletonLoader className="h-10 w-48 rounded" />
                <div className="flex space-x-4 mt-4">
                    <SkeletonLoader className="w-6 h-6 rounded" />
                    <SkeletonLoader className="w-6 h-6 rounded" />
                </div>
                <div className="border-t border-gray-700 w-full my-6"></div>
                <SkeletonLoader className="h-6 w-40 rounded mb-4" />
                <SkeletonLoader className="h-12 w-full rounded-lg mb-3" />
                <SkeletonLoader className="h-12 w-full rounded-lg" />
            </div>
        );
    }

    return (
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-2xl shadow-2xl border border-gray-700 flex flex-col items-center text-center">
             <div className="p-3 bg-emerald-400/10 rounded-full mb-4">
                <UserIcon className="w-12 h-12 text-emerald-400" />
            </div>
            <h2 className="text-2xl font-bold text-white">{profile.name}</h2>
            <p className="text-gray-400 mt-2 text-sm max-w-xs min-h-[40px]">{profile.bio}</p>
            <div className="flex space-x-4 mt-4">
                <a href={profile.socials.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-pink-500 transition-colors">
                    <InstagramIcon className="w-6 h-6" />
                </a>
                <a href={profile.socials.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors">
                    <LinkedInIcon className="w-6 h-6" />
                </a>
            </div>
            
            <div className="border-t border-gray-700 w-full my-6"></div>

            <h3 className="text-lg font-semibold text-gray-300 mb-4">Share Your Profile</h3>

            <div className="w-full space-y-3">
                 <button 
                    onClick={() => setShowQrModal(true)}
                    className="w-full flex items-center justify-center space-x-3 bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-opacity-75"
                >
                    <QrCodeIcon className="w-6 h-6" />
                    <span>Share via QR Code</span>
                </button>
                <button 
                    onClick={handleTapCard}
                    disabled={isTappingCard}
                    className="w-full flex items-center justify-center space-x-3 bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-opacity-75 disabled:opacity-70 disabled:scale-100 disabled:cursor-not-allowed"
                >
                    <CreditCardIcon className="w-6 h-6" />
                    <span>{isTappingCard ? 'Sharing...' : 'Use PatSwap NFC Card'}</span>
                </button>
            </div>
            
            {isTappingCard && <p className="text-emerald-300 text-xs mt-3 animate-pulse">Ready to connect! Tap your card on another device.</p>}
            
            {showQrModal && profile && <QrCodeModal profile={profile} onClose={() => setShowQrModal(false)} />}
        </div>
    );
};

export default ProfileCard;

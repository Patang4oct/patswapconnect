import React, { useState } from 'react';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import MapPinIcon from './icons/MapPinIcon';

const FriendMap: React.FC<{onClose: () => void}> = ({onClose}) => (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 w-full max-w-lg shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
                 <h3 className="text-lg font-bold text-white">Friend Locations</h3>
                 <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl leading-none">&times;</button>
            </div>
           <p className="text-sm text-gray-400 mb-4">This is a simulation of where your connected friends are located in real-time at the fest.</p>
           <div className="aspect-video bg-gray-700 rounded-lg overflow-hidden relative">
                {/* Simplified SVG Map Background */}
                <svg width="100%" height="100%" viewBox="0 0 400 225" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 0H400V225H0V0Z" fill="#4A5568"/>
                    <path d="M50 50 H150 V100 H50 Z" fill="#2D3748" stroke="#718096" strokeWidth="1"/>
                    <text x="70" y="80" fontFamily="sans-serif" fontSize="10" fill="#E2E8F0">Main Stage</text>
                    <path d="M250 150 H350 V200 H250 Z" fill="#2D3748" stroke="#718096" strokeWidth="1"/>
                    <text x="275" y="180" fontFamily="sans-serif" fontSize="10" fill="#E2E8F0">Food Court</text>
                    <circle cx="200" cy="100" r="30" fill="#2D3748" stroke="#718096" strokeWidth="1"/>
                    <text x="185" y="105" fontFamily="sans-serif" fontSize="10" fill="#E2E8F0">Chill Zone</text>
                </svg>
                {/* Friend Pins */}
                <div className="absolute top-[30%] left-[40%] animate-pulse">
                    <MapPinIcon className="w-6 h-6 text-emerald-400"/>
                </div>
                 <div className="absolute top-[70%] left-[80%] animate-pulse" style={{animationDelay: '0.5s'}}>
                    <MapPinIcon className="w-6 h-6 text-amber-400"/>
                </div>
                 <div className="absolute top-[50%] left-[20%] animate-pulse" style={{animationDelay: '1s'}}>
                    <MapPinIcon className="w-6 h-6 text-pink-500"/>
                </div>
           </div>
        </div>
    </div>
);


const SafetyFeatures: React.FC = () => {
    const [sosSent, setSosSent] = useState(false);
    const [showMap, setShowMap] = useState(false);
    const [isSosActive, setIsSosActive] = useState(false);

    const handleSos = () => {
        setIsSosActive(true);
        setSosSent(true);
        setTimeout(() => {
            setIsSosActive(false);
        }, 5000);
    };

  return (
    <div className="bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-700">
        <div className="flex items-center mb-4">
            <ShieldCheckIcon className="w-6 h-6 text-emerald-400 mr-3"/>
            <h3 className="text-xl font-bold text-white">Safety Zone</h3>
        </div>
        <p className="text-gray-400 text-sm mb-4">Stay safe and keep track of your friends during the fest.</p>
        <div className="space-y-3">
             <button onClick={() => setShowMap(true)} className="w-full text-left bg-gray-700 hover:bg-gray-600 text-white font-semibold py-3 px-4 rounded-lg transition-colors">
                Track Friends on Map
            </button>
            <button 
                onClick={handleSos}
                disabled={isSosActive}
                className={`w-full text-left text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 disabled:opacity-75 disabled:cursor-not-allowed ${
                    isSosActive 
                    ? 'bg-red-700 animate-pulse' 
                    : 'bg-red-600/80 hover:bg-red-600'
                }`}
            >
                {isSosActive ? 'Alert Sent!' : 'Emergency SOS'}
            </button>
        </div>
        {sosSent && <p className={`text-red-400 text-xs mt-2 transition-opacity duration-500 ${isSosActive ? 'opacity-100' : 'opacity-0'}`}>Your emergency contacts have been notified.</p>}
        {showMap && <FriendMap onClose={() => setShowMap(false)} />}
    </div>
  );
};

export default SafetyFeatures;

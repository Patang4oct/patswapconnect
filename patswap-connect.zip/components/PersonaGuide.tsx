import React from 'react';
import UserIcon from './icons/UserIcon';

interface PersonaGuideProps {
    username: string;
}

const PersonaGuide: React.FC<PersonaGuideProps> = ({ username }) => {
    return (
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 border border-emerald-500/30 rounded-2xl p-6 mb-6 text-center animate-[fadeIn_0.5s_ease-in-out]">
            <div className="p-3 bg-emerald-400/10 rounded-full mb-4 inline-block">
                 <UserIcon className="w-10 h-10 text-emerald-400" />
            </div>
            <h2 className="text-2xl font-bold text-white">Welcome, {username}!</h2>
            <p className="text-gray-400 mt-2 max-w-lg mx-auto">
                Let's set up your profile for the fest. Your "Persona" shapes the AI-generated identity you'll use to connect with others.
            </p>
            <p className="mt-4 text-sm text-emerald-300 font-semibold">
                Start by selecting a Persona from the dropdown above to generate your unique profile card.
            </p>
        </div>
    );
};

export default PersonaGuide;

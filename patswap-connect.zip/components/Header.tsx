import React from 'react';
import NfcIcon from './icons/NfcIcon';

type AppView = 'live' | 'afterparty';

interface HeaderProps {
  isLoggedIn: boolean;
  onLogout: () => void;
  currentView: AppView;
  onViewChange: (view: AppView) => void;
}

const Header: React.FC<HeaderProps> = ({ isLoggedIn, onLogout, currentView, onViewChange }) => {
  return (
    <header className="p-4 bg-gray-900/80 backdrop-blur-sm sticky top-0 z-20 border-b border-gray-700">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
            <NfcIcon className="w-8 h-8 text-emerald-400 mr-3" />
            <h1 className="text-2xl font-bold tracking-tight text-white">
            PatSwap <span className="text-emerald-400">Connect</span>
            </h1>
        </div>
        {isLoggedIn && (
            <div className="flex items-center gap-4">
                <div className="p-1 bg-gray-800 rounded-lg flex items-center border border-gray-700">
                    <button
                        onClick={() => onViewChange('live')}
                        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
                            currentView === 'live' ? 'bg-emerald-500 text-black' : 'text-gray-300 hover:bg-gray-700'
                        }`}
                    >
                        Live Fest
                    </button>
                    <button
                        onClick={() => onViewChange('afterparty')}
                        className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
                            currentView === 'afterparty' ? 'bg-emerald-500 text-black' : 'text-gray-300 hover:bg-gray-700'
                        }`}
                    >
                        Afterparty
                    </button>
                </div>

                <button 
                    onClick={onLogout}
                    className="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
                >
                    Logout
                </button>
            </div>
        )}
      </div>
    </header>
  );
};

export default Header;

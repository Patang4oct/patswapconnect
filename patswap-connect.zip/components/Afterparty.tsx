import React from 'react';
import { User } from '../types';
import CalendarDaysIcon from './icons/CalendarDaysIcon';
import UserGroupIcon from './icons/UserGroupIcon';
import ReconnectCard from './ReconnectCard';

interface AfterpartyProps {
    user: User;
}

const Afterparty: React.FC<AfterpartyProps> = ({ user }) => {
    return (
        <div className="animate-[fadeIn_0.5s_ease-in-out]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-2xl p-6 flex items-center space-x-4">
                    <div className="p-3 bg-emerald-400/10 rounded-full">
                        <CalendarDaysIcon className="w-8 h-8 text-emerald-400" />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white">Your Fest Recap</h2>
                        <p className="text-gray-400">A look back at your event experience.</p>
                    </div>
                </div>
                 <div className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-2xl p-6 flex items-center space-x-4">
                    <div className="p-3 bg-amber-400/10 rounded-full">
                        <UserGroupIcon className="w-8 h-8 text-amber-400" />
                    </div>
                    <div>
                        <h2 className="text-3xl font-bold text-white">{user.connections.length}</h2>
                        <p className="text-gray-400">New Connections Made</p>
                    </div>
                </div>
            </div>

            <div>
                <h3 className="text-2xl font-bold text-white mb-4">Reconnect with Your Crew</h3>
                {user.connections.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {user.connections.filter(c => !c.isLoading).map(connection => (
                            <ReconnectCard key={connection.id} userPersona={user.selectedPersona} connection={connection} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-16 bg-gray-800 rounded-2xl border border-gray-700">
                        <p className="text-gray-500">You didn't make any connections during the fest.</p>
                        <p className="text-gray-500 mt-1 text-sm">Next time, try sharing your profile!</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Afterparty;

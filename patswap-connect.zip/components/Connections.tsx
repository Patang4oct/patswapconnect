import React, { useState } from 'react';
import { Profile } from '../types';
import UserGroupIcon from './icons/UserGroupIcon';
import UserIcon from './icons/UserIcon';
import InstagramIcon from './icons/InstagramIcon';
import LinkedInIcon from './icons/LinkedInIcon';
import NfcIcon from './icons/NfcIcon';
import SearchIcon from './icons/SearchIcon';
import SpinnerIcon from './icons/SpinnerIcon';
import SkeletonLoader from './SkeletonLoader';

interface ConnectionsProps {
  connections: Profile[];
  onAddSimulatedConnection: () => void;
  onSearchConnection: (query: string) => Promise<boolean>;
  isAdding: boolean;
}

const ConnectionItem: React.FC<{ profile: Profile }> = ({ profile }) => {
    if (profile.isLoading) {
        return (
            <div className="flex items-center space-x-4 p-3 bg-gray-700/50 rounded-lg">
                 <SkeletonLoader className="w-10 h-10 rounded-full" />
                <div className="flex-1 min-w-0">
                    <SkeletonLoader className="h-4 w-3/4 mb-1.5 rounded" />
                    <SkeletonLoader className="h-3 w-1/2 rounded" />
                </div>
            </div>
        )
    }

    return (
        <div className="flex flex-col p-3 bg-gray-700/50 rounded-lg transition-opacity duration-500 animate-[fadeIn_0.5s_ease-in-out]">
            <div className="flex items-center space-x-4">
                <div className="p-2 bg-emerald-400/10 rounded-full">
                    <UserIcon className="w-6 h-6 text-emerald-400" />
                </div>
                <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white truncate">{profile.name}</p>
                    <p className="text-xs text-gray-400 truncate">{profile.bio}</p>
                </div>
                <div className="flex space-x-2 flex-shrink-0">
                    {profile.socials.instagram &&
                        <a href={profile.socials.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-pink-500">
                            <InstagramIcon className="w-4 h-4" />
                        </a>
                    }
                    {profile.socials.linkedin &&
                        <a href={profile.socials.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-blue-500">
                            <LinkedInIcon className="w-4 h-4" />
                        </a>
                    }
                </div>
            </div>
            {profile.sources && profile.sources.length > 0 && (
                <div className="mt-2 pt-2 border-t border-gray-600/50 text-xs text-gray-500">
                    <strong>Sources:</strong>{' '}
                    {profile.sources.map((source, i) => (
                        <a key={i} href={source.uri} target="_blank" rel="noopener noreferrer" className="underline hover:text-emerald-400 transition-colors">
                            {source.title || new URL(source.uri).hostname}
                            {i < (profile.sources?.length ?? 0) - 1 ? ', ' : ''}
                        </a>
                    ))}
                </div>
            )}
        </div>
    )
};

const Connections: React.FC<ConnectionsProps> = ({ connections, onAddSimulatedConnection, onSearchConnection, isAdding }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [searchError, setSearchError] = useState<string | null>(null);


    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) return;
        setIsSearching(true);
        setSearchError(null);
        const success = await onSearchConnection(searchQuery);
        if (!success) {
            setSearchError(`Profile for "${searchQuery}" not found. Try another name.`);
        }
        setIsSearching(false);
        setSearchQuery('');
    };

  return (
    <div className="bg-gray-800 p-6 rounded-2xl shadow-lg border border-gray-700 h-full flex flex-col">
        <div className="flex items-center mb-4">
            <UserGroupIcon className="w-6 h-6 text-emerald-400 mr-3"/>
            <h3 className="text-xl font-bold text-white">My Connections</h3>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2 mb-4">
            <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for a public figure..."
                className="flex-grow bg-gray-700 border border-gray-600 text-white rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
                disabled={isSearching}
            />
            <button type="submit" className="bg-gray-600 hover:bg-gray-500 text-white font-bold p-2.5 rounded-lg transition-colors disabled:opacity-50 flex items-center justify-center w-11" disabled={isSearching}>
                {isSearching ? <SpinnerIcon /> : <SearchIcon className="w-5 h-5" />}
            </button>
        </form>

        <div className="flex-grow space-y-3 overflow-y-auto pr-2 -mr-2">
            {searchError && <p className="text-amber-400 text-sm text-center p-3 bg-amber-900/50 rounded-lg">{searchError}</p>}
            {connections.length > 0 ? (
                connections.map((conn) => <ConnectionItem key={conn.id || conn.name} profile={conn} />)
            ) : (
                 !searchError && <p className="text-gray-500 text-sm text-center py-8">Search for a celebrity or tap below to simulate receiving a profile!</p>
            )}
        </div>
        <button 
            onClick={onAddSimulatedConnection}
            disabled={isAdding}
            className="mt-4 w-full flex items-center justify-center space-x-2 bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed"
        >
            <NfcIcon className="w-6 h-6" />
            <span>{isAdding ? 'Receiving...' : 'Tap to Receive Profile'}</span>
        </button>
    </div>
  );
};

export default Connections;

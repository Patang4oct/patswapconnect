import React, { useState, FormEvent } from 'react';
import * as authService from '../services/authService';
import { User } from '../types';
import NfcIcon from './icons/NfcIcon';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAuthSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
        const response = isLoginView
            ? await authService.login(username, password)
            : await authService.signup(username, password);

        if (response.user) {
            onLoginSuccess(response.user);
        } else {
            setError(response.error);
        }
    } catch (err: any) {
        setError(err.message || 'An unexpected error occurred.');
    } finally {
        setIsLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setError(null);
    setIsLoading(true);
    const response = await authService.loginAsDemoUser();
    onLoginSuccess(response.user);
    setIsLoading(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center">
                 <NfcIcon className="w-10 h-10 text-emerald-400 mr-3" />
                <h1 className="text-3xl font-bold tracking-tight text-white">
                PatSwap <span className="text-emerald-400">Connect</span>
                </h1>
            </div>
            <p className="text-gray-400 mt-2">Connect safely at your next university fest.</p>
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-8 shadow-2xl">
          <h2 className="text-2xl font-bold text-white text-center mb-6">{isLoginView ? 'Welcome Back' : 'Create Account'}</h2>
          
          <div className="space-y-4">
             <button
                onClick={handleDemoLogin}
                disabled={isLoading}
                className="w-full bg-amber-500 hover:bg-amber-600 text-black font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-70 disabled:scale-100 disabled:cursor-wait"
              >
                Continue as Demo User
              </button>

              <div className="flex items-center">
                <div className="flex-grow border-t border-gray-600"></div>
                <span className="flex-shrink mx-4 text-gray-500 text-xs">OR</span>
                <div className="flex-grow border-t border-gray-600"></div>
              </div>
          </div>


          <form onSubmit={handleAuthSubmit} className="space-y-6 mt-4">
            <div>
              <label className="text-sm font-bold text-gray-300 block mb-2" htmlFor="username">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-3 bg-gray-700 rounded-lg border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                required
              />
            </div>
            <div>
              <label className="text-sm font-bold text-gray-300 block mb-2" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 bg-gray-700 rounded-lg border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                required
              />
            </div>
            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-70 disabled:scale-100 disabled:cursor-wait"
              >
                {isLoading ? 'Processing...' : (isLoginView ? 'Login' : 'Sign Up')}
              </button>
            </div>
          </form>
          <div className="text-center mt-6">
            <button onClick={() => { setIsLoginView(!isLoginView); setError(null); }} className="text-sm text-emerald-400 hover:underline">
              {isLoginView ? 'Need an account? Sign Up' : 'Already have an account? Login'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
